/*ce script sert à montrer ou cacher la zone d'erreur*/

function cacher(){ 
	(document.getElementById('infoERREUR')).style.display = "none";
	}

function montrer(){ 
	(document.getElementById('infoERREUR')).style.display = "";
	} 