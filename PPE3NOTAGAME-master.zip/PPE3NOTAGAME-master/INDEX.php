<?php
// redirection vers la page index dans la VUE
header ( 'Location: ./VUE/index.php');
?>